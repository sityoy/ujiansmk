<a href="tambah_siswa.php" class="btn">
➕ Tambah Siswa
</a>

<a href="download_template_siswa.php" class="btn">
📥 Template Excel
</a>