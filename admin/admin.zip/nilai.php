<?php
session_start();
require '../koneksi.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

// 1. Ambil daftar mapel unik yang ada di tabel ujian untuk dropdown filter
$stmtMapel = $pdo->query("SELECT DISTINCT mata_pelajaran FROM ujian_siswa WHERE mata_pelajaran IS NOT NULL");
$list_mapel = $stmtMapel->fetchAll();

// 2. Setup Filter & Pagination
$mapel_filter = isset($_GET['mapel']) ? $_GET['mapel'] : '';
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 20; // Sesuai request: Minimal 20 per halaman

$where = "WHERE 1=1";
$params = [];

if ($mapel_filter != '') {
    $where .= " AND u.mata_pelajaran = ?";
    $params[] = $mapel_filter;
}

// Hitung total data untuk Pagination
$stmtCount = $pdo->prepare("SELECT COUNT(*) FROM ujian_siswa u $where");
$stmtCount->execute($params);
$total_data = $stmtCount->fetchColumn();

// Jika user memilih "All", tampilkan semua data tanpa limit
if ($page === 'all') {
    $limit_query = "";
    $total_pages = 1;
} else {
    $page = (int)$page;
    $offset = ($page - 1) * $limit;
    $limit_query = "LIMIT $limit OFFSET $offset";
    $total_pages = ceil($total_data / $limit);
}

// 3. Ambil Data Nilai (Join dengan tabel siswa)
$query = "SELECT u.*, s.kartu_peserta, s.nama_siswa, s.kelas 
          FROM ujian_siswa u 
          JOIN siswa s ON u.siswa_id = s.id 
          $where ORDER BY u.id DESC $limit_query";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$data_nilai = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Rekap Nilai Siswa</title>
    <style>
        body { font-family: Arial; background: #f4f7f6; margin: 0; padding: 20px; }
        .navbar { background: #007bff; padding: 15px; color: white; border-radius: 5px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;}
        .navbar a { color: white; text-decoration: none; font-weight: bold; padding: 0 15px; }
        .card { background: white; padding: 20px; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: center; }
        th { background-color: #007bff; color: white; }
        .btn-danger { background: #dc3545; color: white; padding: 6px 12px; text-decoration: none; border-radius: 3px; font-size: 12px; }
        .btn-primary { background: #007bff; color: white; padding: 8px 15px; text-decoration: none; border-radius: 3px; border: none; cursor: pointer;}
        
        /* Pagination Styles */
        .pagination { margin-top: 20px; display: flex; justify-content: center; gap: 5px; }
        .pagination a { padding: 8px 12px; border: 1px solid #007bff; text-decoration: none; color: #007bff; border-radius: 3px; }
        .pagination a.active, .pagination a:hover { background: #007bff; color: white; }
        .filter-box { margin-bottom: 15px; background: #e9ecef; padding: 15px; border-radius: 5px; }
    </style>
</head>
<body>

    <?php include 'navbar.php'; ?>

    <div class="card">
        <h2>Rekap Nilai Ujian Siswa</h2>
        
        <div class="filter-box">
            <form method="GET" action="nilai.php" style="display:flex; align-items:center; gap: 10px;">
                <label><strong>Filter Mapel:</strong></label>
                <select name="mapel" style="padding: 8px; border-radius: 4px; border: 1px solid #ccc;">
                    <option value="">-- Semua Mata Pelajaran --</option>
                    <?php foreach($list_mapel as $lm): ?>
                        <option value="<?php echo htmlspecialchars($lm['mata_pelajaran']); ?>" <?php if($mapel_filter == $lm['mata_pelajaran']) echo 'selected'; ?>>
                            <?php echo htmlspecialchars($lm['mata_pelajaran']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn-primary">Tampilkan</button>
            </form>
        </div>

        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>No. Peserta</th>
                    <th>Nama Siswa</th>
                    <th>Kelas</th>
                    <th>Mapel</th>
                    <th>Nilai</th>
                    <th>Pelanggaran</th>
                    <th>Selfie</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($data_nilai)): ?>
                    <tr><td colspan="9">Belum ada data nilai.</td></tr>
                <?php else: ?>
                    <?php 
                    $no = ($page === 'all') ? 1 : $offset + 1; 
                    foreach ($data_nilai as $row): 
                    ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo htmlspecialchars($row['kartu_peserta']); ?></td>
                            <td style="text-align: left;"><?php echo htmlspecialchars($row['nama_siswa']); ?></td>
                            <td><?php echo htmlspecialchars($row['kelas']); ?></td>
                            <td><?php echo htmlspecialchars($row['mata_pelajaran']); ?></td>
                            <td><strong style="font-size: 18px; color: #28a745;"><?php echo number_format($row['nilai'], 2); ?></strong></td>
                            <td>
                                <?php if($row['jumlah_pelanggaran'] >= 20): ?>
                                    <span style="color: red; font-weight: bold;">DISKUALIFIKASI (<?php echo $row['jumlah_pelanggaran']; ?>x)</span>
                                <?php else: ?>
                                    <?php echo $row['jumlah_pelanggaran']; ?>x
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($row['foto_selfie']): ?>
                                    <img src="../assets/<?php echo $row['foto_selfie']; ?>" width="50" style="border-radius: 5px;">
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td>

    <a
        href="detail_nilai.php?id=<?php echo $row['id']; ?>"
        class="btn-primary"
        style="
            display:block;
            margin-bottom:5px;
            text-decoration:none;
            text-align:center;
        "
    >
        Detail
    </a>

    <a
        href="reset_ujian.php?id_ujian=<?php echo $row['id']; ?>&id_siswa=<?php echo $row['siswa_id']; ?>"
        class="btn-danger"
        onclick="return confirm('Yakin reset ujian?')"
    >
        Reset Ujian
    </a>

</td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <?php if ($total_pages > 1 && $page !== 'all'): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?mapel=<?php echo urlencode($mapel_filter); ?>&page=<?php echo $page - 1; ?>">&laquo; Prev</a>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?mapel=<?php echo urlencode($mapel_filter); ?>&page=<?php echo $i; ?>" class="<?php echo ($page == $i) ? 'active' : ''; ?>">
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>

                <?php if ($page < $total_pages): ?>
                    <a href="?mapel=<?php echo urlencode($mapel_filter); ?>&page=<?php echo $page + 1; ?>">Next &raquo;</a>
                <?php endif; ?>
                
                <a href="?mapel=<?php echo urlencode($mapel_filter); ?>&page=all" style="margin-left: 10px; background: #17a2b8; color: white; border-color: #17a2b8;">Lihat Semua (All)</a>
            </div>
        <?php elseif ($page === 'all'): ?>
             <div class="pagination">
                 <a href="?mapel=<?php echo urlencode($mapel_filter); ?>&page=1" style="background: #6c757d; color: white; border-color: #6c757d;">Kembali ke Tampilan Halaman (20 Data)</a>
             </div>
        <?php endif; ?>

    </div>
</body>
</html>