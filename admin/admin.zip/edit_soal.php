<?php
session_start();
require '../koneksi.php';

// Pastikan admin sudah login dan ada ID soal yang dikirim
if (!isset($_SESSION['admin_id']) || !isset($_GET['id'])) {
    header("Location: soal.php");
    exit;
}

$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM soal WHERE id = ?");
$stmt->execute([$id]);
$soal = $stmt->fetch();

if (!$soal) {
    die("Soal tidak ditemukan!");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Tangkap semua inputan
    $mata_pelajaran = $_POST['mata_pelajaran'];
    $deskripsi = $_POST['deskripsi'];
    $pertanyaan = $_POST['pertanyaan'];
    $opsi_a = $_POST['opsi_a'];
    $gambar_a = $soal['gambar_a'];
    $opsi_b = $_POST['opsi_b'];
    $gambar_b = $soal['gambar_b'];
    $opsi_c = $_POST['opsi_c'];
    $gambar_c = $soal['gambar_c'];
    $opsi_d = $_POST['opsi_d'];
    $gambar_d = $soal['gambar_d'];
    $opsi_e = $_POST['opsi_e'];
    $gambar_e = $soal['gambar_e'];
    $kunci = $_POST['kunci_jawaban'];
    
    // Secara default, gunakan nama gambar lama
    $gambar = $soal['gambar']; 

    // Proses jika Admin mengupload gambar baru
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == 0) {
        $ext = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
        $gambar_baru = "soal_" . time() . "." . $ext;
        $target_dir = "../uploads/";

    foreach(['a','b','c','d','e'] as $opt){

        if(
            isset($_FILES['gambar_'.$opt]) &&
            $_FILES['gambar_'.$opt]['error'] == 0
        ){

            $ext = pathinfo(
                $_FILES['gambar_'.$opt]['name'],
                PATHINFO_EXTENSION
            );

            $nama_file =
                "opsi_".$opt."_".time()."_".rand(100,999).".".$ext;

            if(
                move_uploaded_file(
                    $_FILES['gambar_'.$opt]['tmp_name'],
                    $target_dir.$nama_file
                )
            ){

                $gambar_lama = ${"gambar_".$opt};

                if(
                    !empty($gambar_lama) &&
                    file_exists($target_dir.$gambar_lama)
                ){
                    unlink($target_dir.$gambar_lama);
                }

                ${"gambar_".$opt} = $nama_file;
            }
        }
    }
        
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        
        // Pindahkan gambar baru
        if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target_dir . $gambar_baru)) {
            // Hapus gambar lama dari server (agar folder hosting tidak penuh)
            if (!empty($soal['gambar']) && file_exists($target_dir . $soal['gambar'])) {
                unlink($target_dir . $soal['gambar']);
            }
            $gambar = $gambar_baru; // Set nama gambar menjadi yang baru diupdate
        }
    }

    try {
        // Update database dengan struktur terbaru
        $stmtUpdate = $pdo->prepare("UPDATE soal SET mata_pelajaran=?, deskripsi=?, gambar=?, pertanyaan=?,  opsi_a=?, gambar_a=?, opsi_b=?, gambar_b=?, opsi_c=?, gambar_c=?, opsi_d=?, gambar_d=?, opsi_e=?, gambar_e=?, kunci_jawaban=? WHERE id=?");
        $stmtUpdate->execute([
            $mata_pelajaran,
            $deskripsi,
            $gambar,
            $pertanyaan,

            $opsi_a,
            $gambar_a,

            $opsi_b,
            $gambar_b,

            $opsi_c,
            $gambar_c,

            $opsi_d,
            $gambar_d,

            $opsi_e,
            $gambar_e,

            $kunci,
            $id
        ]);
        
        echo "<script>alert('Soal berhasil diupdate!'); window.location='soal.php';</script>";
    } catch (Exception $e) {
        die("Gagal mengupdate soal: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Soal</title>
    <script src="https://cdn.ckeditor.com/4.22.1/standard/ckeditor.js"></script>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f7f6; padding: 20px; margin: 0; }
        .card { background: white; padding: 30px; border-radius: 5px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); max-width: 900px; margin: auto; border-top: 4px solid #17a2b8; }
        .form-group { margin-bottom: 20px; }
        label { font-weight: bold; display: block; margin-bottom: 8px; color: #333; }
        input[type="text"], select { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        .btn { background: #28a745; color: white; padding: 12px 25px; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; font-size: 15px; }
        .btn:hover { background: #1e7e34; }
        .btn-batal { background: #6c757d; text-decoration: none; padding: 12px 25px; color: white; border-radius: 4px; display: inline-block; margin-left: 10px; font-weight: bold; font-size: 15px; }
        .btn-batal:hover { background: #5a6268; }
        .img-preview { margin-top: 10px; max-width: 200px; border: 1px solid #ddd; padding: 5px; border-radius: 4px; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Edit Soal</h2>
        
        <form method="POST" enctype="multipart/form-data">
            
            <div class="form-group">
                <label>Mata Pelajaran (*Wajib):</label>
                <input type="text" name="mata_pelajaran" value="<?php echo htmlspecialchars($soal['mata_pelajaran']); ?>" required>
            </div>

            <div class="form-group">
                <label>1. Deskripsi / Pernyataan (Opsional):</label>
                <textarea name="deskripsi" id="editor-deskripsi"><?php echo $soal['deskripsi']; ?></textarea>
            </div>
            
            <div class="form-group">
                <label>2. Gambar Soal:</label>
                <?php if(!empty($soal['gambar'])): ?>
                    <div>
                        <img src="../uploads/<?php echo htmlspecialchars($soal['gambar']); ?>" class="img-preview" alt="Gambar Soal"><br>
                        <small style="color: #666;">*Biarkan kosong jika tidak ingin mengganti gambar.</small>
                    </div>
                <?php else: ?>
                    <small style="color: #666;">*Saat ini tidak ada gambar. Silakan upload jika ingin menambahkan.</small>
                <?php endif; ?>
                <input type="file" name="gambar" accept="image/*" style="margin-top: 10px; display: block;">
            </div>

            <div class="form-group">
                <label>3. Soal / Pertanyaan (*Wajib):</label>
                <textarea name="pertanyaan" id="editor-pertanyaan" required><?php echo $soal['pertanyaan']; ?></textarea>
            </div>

            <div class="form-group"><label>Opsi A:</label><input type="text" name="opsi_a" value="<?php echo htmlspecialchars($soal['opsi_a']); ?>" required>
                <?php if(!empty($soal['gambar_a'])): ?>
                    <br>
                    <img src="../uploads/<?php echo $soal['gambar_a']; ?>" style="max-width:120px;margin-top:10px;">
                <?php endif; ?>

                <input type="file" name="gambar_a" accept="image/*">
            </div>
            
            <div class="form-group"><label>Opsi B:</label><input type="text" name="opsi_b" value="<?php echo htmlspecialchars($soal['opsi_b']); ?>" required>
                <?php if(!empty($soal['gambar_b'])): ?>
                    <br>
                    <img src="../uploads/<?php echo $soal['gambar_b']; ?>" style="max-width:120px;margin-top:10px;">
                <?php endif; ?>

                <input type="file" name="gambar_b" accept="image/*">
            </div>

            <div class="form-group"><label>Opsi C:</label><input type="text" name="opsi_c" value="<?php echo htmlspecialchars($soal['opsi_c']); ?>" required>
                <?php if(!empty($soal['gambar_c'])): ?>
                    <br>
                    <img src="../uploads/<?php echo $soal['gambar_c']; ?>" style="max-width:120px;margin-top:10px;">
                <?php endif; ?>

                <input type="file" name="gambar_c" accept="image/*">
            </div>

            <div class="form-group"><label>Opsi D:</label><input type="text" name="opsi_d" value="<?php echo htmlspecialchars($soal['opsi_d']); ?>" required>
                <?php if(!empty($soal['gambar_d'])): ?>
                    <br>
                    <img src="../uploads/<?php echo $soal['gambar_d']; ?>" style="max-width:120px;margin-top:10px;">
                <?php endif; ?>

                <input type="file" name="gambar_d" accept="image/*">
            </div>

            <div class="form-group"><label>Opsi C:</label><input type="text" name="opsi_e" value="<?php echo htmlspecialchars($soal['opsi_e']); ?>" required>
                <?php if(!empty($soal['gambar_e'])): ?>
                    <br>
                    <img src="../uploads/<?php echo $soal['gambar_e']; ?>" style="max-width:120px;margin-top:10px;">
                <?php endif; ?>

                <input type="file" name="gambar_e" accept="image/*">
            </div>

            <div class="form-group">
                <label>Kunci Jawaban:</label>
                <select name="kunci_jawaban" required>
                    <option value="A" <?php if($soal['kunci_jawaban'] == 'A') echo 'selected'; ?>>A</option>
                    <option value="B" <?php if($soal['kunci_jawaban'] == 'B') echo 'selected'; ?>>B</option>
                    <option value="C" <?php if($soal['kunci_jawaban'] == 'C') echo 'selected'; ?>>C</option>
                    <option value="D" <?php if($soal['kunci_jawaban'] == 'D') echo 'selected'; ?>>D</option>
                    <option value="E" <?php if($soal['kunci_jawaban'] == 'E') echo 'selected'; ?>>E</option>
                </select>
            </div>
            
            <hr style="margin: 30px 0; border: 0; border-top: 1px solid #eee;">
            <button type="submit" class="btn">Update Soal</button>
            <a href="soal.php" class="btn-batal">Batal</a>
        </form>
    </div>
    
    <script>
        // Inisialisasi CKEditor untuk form edit
        CKEDITOR.replace('editor-deskripsi', { height: 150 });
        CKEDITOR.replace('editor-pertanyaan', { height: 150 });
    </script>
</body>
</html>