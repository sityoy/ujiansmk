<?php
session_start();
require '../koneksi.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

// 1. Ambil daftar mapel unik yang ada di tabel soal untuk dropdown filter
$stmtMapel = $pdo->query("SELECT DISTINCT mata_pelajaran FROM soal WHERE mata_pelajaran IS NOT NULL AND mata_pelajaran != ''");
$list_mapel = $stmtMapel->fetchAll();

// 2. Setup Filter Mapel
$mapel_filter = isset($_GET['mapel']) ? $_GET['mapel'] : '';
$where = "WHERE 1=1";
$params = [];

if ($mapel_filter != '') {
    $where .= " AND mata_pelajaran = ?";
    $params[] = $mapel_filter;
}

// 3. Ambil soal berdasarkan filter
$stmtSoal = $pdo->prepare("SELECT * FROM soal $where ORDER BY id DESC");
$stmtSoal->execute($params);
$soal_list = $stmtSoal->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen Soal - Admin</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f7f6; margin: 0; padding: 20px; }
        .navbar { background: #007bff; padding: 15px; color: white; border-radius: 5px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .navbar a { color: white; text-decoration: none; font-weight: bold; padding: 0 15px; }
        .card { background: white; padding: 20px; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 20px; }
        
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; vertical-align: top; }
        th { background-color: #007bff; color: white; }
        
        .btn { display: inline-block; background: #28a745; color: white; padding: 10px 15px; text-decoration: none; border-radius: 4px; border: none; cursor: pointer; font-size: 14px; font-weight: bold; }
        .btn-primary { background: #007bff; }
        .btn-info { background: #17a2b8; padding: 6px 12px; font-size: 13px; }
        .btn-danger { background: #dc3545; padding: 6px 12px; font-size: 13px; }
        .btn:hover, .btn-info:hover, .btn-danger:hover { opacity: 0.9; }
        
        .header-action { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .filter-box { background: #e9ecef; padding: 15px; border-radius: 5px; margin-bottom: 15px; display: flex; align-items: center; gap: 10px; }
        .badge-mapel { background: #ffc107; color: #333; padding: 4px 8px; border-radius: 3px; font-size: 12px; font-weight: bold; display: inline-block; margin-bottom: 8px; }
    </style>
</head>
<body>

    <?php include 'navbar.php'; ?>

    <!-- KOTAK IMPORT SOAL EXCEL -->
    <div class="card">
        <div class="header-action">
            <h3 style="margin: 0;">Import Soal via Excel (.xlsx)</h3>
        </div>
        <p style="font-size: 14px; color: #555;">
            Format Excel: <strong>Kolom A:</strong> Deskripsi | <strong>Kolom B:</strong> Gambar | <strong>Kolom C:</strong> Pertanyaan | <strong>Kolom D-H:</strong> Opsi A-E | <strong>Kolom I:</strong> Kunci (A/B/C/D/E)
        </p>
        
        <form action="download_template.php" method="POST" enctype="multipart/form-data" style="background: #f8f9fa; padding: 15px; border-radius: 5px; border: 1px solid #ddd;">
            <div style="margin-bottom: 15px;">
                <label style="font-weight: bold; display: block; margin-bottom: 5px;">Mata Pelajaran (Untuk soal yang diimport):</label>
                <input type="text" name="mata_pelajaran" placeholder="Contoh: Akuntansi Keuangan" required style="width: 100%; max-width: 400px; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">
            </div>
            <div style="display: flex; gap: 10px; align-items: center;">
                <input type="file" name="file_excel" accept=".xlsx" required style="padding: 5px;">
                <button type="submit" class="btn">Upload & Import</button>
            </div>

            <a href="download_template.php" class="btn btn-info" style="margin-top:10px;display:inline-block;"> Download Template Excel</a>
        </form>
    </div>

    <!-- KOTAK DAFTAR SOAL & FILTER -->
    <div class="card">
        <div class="header-action">
            <h3 style="margin: 0;">Daftar Bank Soal</h3>
            <a href="tambah_soal.php" class="btn btn-primary">➕ Tambah Soal Manual</a>
        </div>

        <!-- Fitur Filter Dropdown -->
        <div class="filter-box">
            <form method="GET" action="soal.php" style="display:flex; align-items:center; gap: 10px; width: 100%;">
                <label style="font-weight: bold;">Filter Berdasarkan Mapel:</label>
                <select name="mapel" style="padding: 8px 12px; border-radius: 4px; border: 1px solid #ccc; flex-grow: 1; max-width: 300px;">
                    <option value="">-- Tampilkan Semua Mapel --</option>
                    <?php foreach($list_mapel as $lm): ?>
                        <option value="<?php echo htmlspecialchars($lm['mata_pelajaran']); ?>" <?php if($mapel_filter == $lm['mata_pelajaran']) echo 'selected'; ?>>
                            <?php echo htmlspecialchars($lm['mata_pelajaran']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-primary" style="padding: 8px 15px;">Filter</button>
            </form>
        </div>

        <!-- Tabel Soal -->
        <table>
            <thead>
                <tr>
                    <th width="5%">No</th>
                    <th width="45%">Soal & Deskripsi</th>
                    <th width="35%">Pilihan Ganda & Kunci</th>
                    <th width="15%">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($soal_list)): ?>
                    <tr><td colspan="4" style="text-align:center; padding: 20px;">Belum ada data soal untuk kriteria ini. Silakan tambahkan atau import soal.</td></tr>
                <?php else: ?>
                    <?php $no = 1; foreach ($soal_list as $s): ?>
                        <tr>
                            <td style="text-align: center; font-weight: bold;"><?php echo $no++; ?></td>
                            <td>
                                <!-- Label Mata Pelajaran -->
                                <span class="badge-mapel"><?php echo htmlspecialchars($s['mata_pelajaran']); ?></span><br>

                                <?php if(!empty($s['deskripsi'])): ?>
                                    <div style="background:#f9f9f9; padding:10px; border-left:4px solid #17a2b8; margin-bottom:10px; font-size:13px; border-radius: 3px; overflow-x: auto;">
                                        <?php echo $s['deskripsi']; ?>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if(!empty($s['gambar'])): ?>
                                    <img src="../uploads/<?php echo htmlspecialchars($s['gambar']); ?>" style="max-width: 150px; border-radius: 4px; border: 1px solid #ddd; margin-bottom: 10px;"><br>
                                <?php endif; ?>
                                
                                <div style="font-size: 15px; margin-top: 5px;">
                                    <?php echo $s['pertanyaan']; ?>
                                </div>
                            </td>
                            <td style="font-size: 14px; line-height: 1.6;">
                                A. <?php echo htmlspecialchars($s['opsi_a']); ?><br>
                                B. <?php echo htmlspecialchars($s['opsi_b']); ?><br>
                                C. <?php echo htmlspecialchars($s['opsi_c']); ?><br>
                                D. <?php echo htmlspecialchars($s['opsi_d']); ?><br>
                                E. <?php echo htmlspecialchars($s['opsi_e']); ?><br>
                                <div style="margin-top: 8px; color: #dc3545; font-weight: bold; font-size: 15px;">
                                    Kunci Jawaban: <?php echo htmlspecialchars($s['kunci_jawaban']); ?>
                                </div>
                            </td>
                            <td style="text-align: center;">
                                <div style="display: flex; flex-direction: column; gap: 8px;">
                                    <a href="edit_soal.php?id=<?php echo $s['id']; ?>" class="btn btn-info" style="text-decoration: none; color: white; display: block; text-align: center;">✏️ Edit</a>
                                    <a href="hapus_soal.php?id=<?php echo $s['id']; ?>" class="btn btn-danger" style="text-decoration: none; color: white; display: block; text-align: center;" onclick="return confirm('Apakah Anda yakin ingin menghapus soal ini secara permanen?')">🗑️ Hapus</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</body>
</html>