<?php
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}
?>

<div class="navbar">
    <div>
        <strong>CBT Panel</strong>
        <a href="index.php">Dashboard</a>
        <a href="soal.php">Kelola Soal</a>
        <a href="jadwal.php">Jadwal Ujian</a>
        <a href="nilai.php">Nilai & Siswa</a>
        <a href="kelola-siswa/siswa.php">Kelola Siswa</a>
    </div>

    <a href="logout.php"
       style="background:red;padding:6px 12px;border-radius:4px;color:white;text-decoration:none;">
       Logout
    </a>
</div>