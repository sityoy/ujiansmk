<?php
session_start();
require '../koneksi.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $mata_pelajaran = $_POST['mata_pelajaran'];
    $deskripsi = $_POST['deskripsi'];
    $pertanyaan = $_POST['pertanyaan'];
    $opsi_a = $_POST['opsi_a'];
    $opsi_b = $_POST['opsi_b'];
    $opsi_c = $_POST['opsi_c'];
    $opsi_d = $_POST['opsi_d'];
    $opsi_e = $_POST['opsi_e'];
    $kunci = $_POST['kunci_jawaban'];
    
    // Proses Upload Gambar Soal Utama
    $gambar = "";
    $target_dir = "../uploads/";
    if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);

    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == 0) {
        $ext = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
        $gambar = "soal_utama_" . time() . "." . $ext;
        move_uploaded_file($_FILES['gambar']['tmp_name'], $target_dir . $gambar);
    }

    // Proses Upload 5 Gambar Opsi (A-E)
    $gbr_opsi = ['a' => '', 'b' => '', 'c' => '', 'd' => '', 'e' => ''];
    foreach (['a', 'b', 'c', 'd', 'e'] as $opt) {
        if (isset($_FILES['gambar_'.$opt]) && $_FILES['gambar_'.$opt]['error'] == 0) {
            $ext = pathinfo($_FILES['gambar_'.$opt]['name'], PATHINFO_EXTENSION);
            $nama_file = "opsi_{$opt}_" . time() . "_" . rand(10,99) . "." . $ext;
            move_uploaded_file($_FILES['gambar_'.$opt]['tmp_name'], $target_dir . $nama_file);
            $gbr_opsi[$opt] = $nama_file;
        }
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO soal (mata_pelajaran, deskripsi, gambar, pertanyaan, opsi_a, gambar_a, opsi_b, gambar_b, opsi_c, gambar_c, opsi_d, gambar_d, opsi_e, gambar_e, kunci_jawaban) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$mata_pelajaran, $deskripsi, $gambar, $pertanyaan, $opsi_a, $gbr_opsi['a'], $opsi_b, $gbr_opsi['b'], $opsi_c, $gbr_opsi['c'], $opsi_d, $gbr_opsi['d'], $opsi_e, $gbr_opsi['e'], $kunci]);
        
        echo "<script>alert('Soal beserta gambar opsi berhasil ditambahkan!'); window.location='soal.php';</script>";
    } catch (Exception $e) {
        die("Gagal menyimpan soal: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang=\"id\">
<head>
    <meta charset="UTF-8">
    <title>Tambah Soal Manual</title>
    <script src="https://cdn.ckeditor.com/4.22.1/standard/ckeditor.js"></script>
    <style>
        body { font-family: Arial; background: #f4f7f6; padding: 20px; }
        .card { background: white; padding: 30px; border-radius: 5px; max-width: 900px; margin: auto; }
        .form-group { margin-bottom: 20px; }
        .opsi-box { background: #f9f9f9; padding: 15px; border-left: 4px solid #28a745; margin-bottom: 15px; }
        label { font-weight: bold; display: block; margin-bottom: 8px; }
        input[type="text"], select { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; margin-bottom: 10px; }
        .btn { background: #007bff; color: white; padding: 12px 25px; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; }
        .btn-batal { background: #6c757d; padding: 12px 25px; color: white; text-decoration: none; border-radius: 4px; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Tambah Soal Baru</h2>
        <form method="POST" enctype="multipart/form-data">
            
            <div class="form-group">
                <label>Mata Pelajaran (*Wajib):</label>
                <input type="text" name="mata_pelajaran" required>
            </div>

            <div class="form-group">
                <label>1. Deskripsi / Pernyataan (Opsional):</label>
                <textarea name="deskripsi" id="editor-deskripsi"></textarea>
            </div>
            
            <div class="form-group">
                <label>2. Upload Gambar Soal Utama (Opsional):</label>
                <input type="file" name="gambar" accept="image/*">
            </div>

            <div class="form-group">
                <label>3. Soal / Pertanyaan (*Wajib):</label>
                <textarea name="pertanyaan" id="editor-pertanyaan" required></textarea>
            </div>

            <hr style="margin: 30px 0;">
            <h3>Pilihan Ganda</h3>

            <?php foreach(['A', 'B', 'C', 'D', 'E'] as $opt): $low_opt = strtolower($opt); ?>
            <div class="opsi-box">
                <label>Opsi <?php echo $opt; ?> (Teks Wajib):</label>
                <input type="text" name="opsi_<?php echo $low_opt; ?>" required>
                
                <label style="font-weight: normal; font-size: 14px;">Upload Gambar Opsi <?php echo $opt; ?> (Opsional):</label>
                <input type="file" name="gambar_<?php echo $low_opt; ?>" accept="image/*">
            </div>
            <?php endforeach; ?>

            <div class="form-group">
                <label>Kunci Jawaban:</label>
                <select name="kunci_jawaban" required>
                    <option value="A">A</option><option value="B">B</option><option value="C">C</option><option value="D">D</option><option value="E">E</option>
                </select>
            </div>

            <button type="submit" class="btn">Simpan Soal</button>
            <a href="soal.php" class="btn-batal">Batal</a>
        </form>
    </div>
    <script>
        CKEDITOR.replace('editor-deskripsi', { height: 150 });
        CKEDITOR.replace('editor-pertanyaan', { height: 150 });
    </script>
</body>
</html>