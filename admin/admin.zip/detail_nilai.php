<?php

session_start();
require '../koneksi.php';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: nilai.php");
    exit;
}

$ujian_id = (int)$_GET['id'];

$stmtInfo = $pdo->prepare("
SELECT
u.*,
s.nama_siswa,
s.kartu_peserta,
s.kelas
FROM ujian_siswa u
JOIN siswa s
ON s.id=u.siswa_id
WHERE u.id=?
");

$stmtInfo->execute([$ujian_id]);

$data = $stmtInfo->fetch();

if(!$data){
    die('Data tidak ditemukan');
}

$stmtJawaban = $pdo->prepare("
SELECT
js.*,
soal.pertanyaan,
soal.kunci_jawaban
FROM jawaban_siswa js
JOIN soal
ON soal.id=js.soal_id
WHERE js.ujian_id=?
");

$stmtJawaban->execute([$ujian_id]);

$jawaban = $stmtJawaban->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>

<title>Detail Nilai</title>

<style>

body{
font-family:Arial;
background:#f4f7f6;
padding:20px;
}

.card{
background:white;
padding:20px;
border-radius:10px;
margin-bottom:20px;
box-shadow:0 2px 5px rgba(0,0,0,.1);
}

.benar{
color:green;
font-weight:bold;
}

.salah{
color:red;
font-weight:bold;
}

</style>

</head>
<body>

<div class="card">

<h2>Detail Hasil Ujian</h2>
<div style="margin-bottom:20px;">

    <a
        href="nilai.php"
        style="
            background:#6c757d;
            color:white;
            padding:10px 15px;
            border-radius:5px;
            text-decoration:none;
            font-weight:bold;
        "
    >
        ← Kembali ke Rekap Nilai
    </a>

</div>

<p>
<b>Nama :</b>
<?php echo htmlspecialchars($data['nama_siswa']); ?>
</p>

<p>
<b>Kelas :</b>
<?php echo htmlspecialchars($data['kelas']); ?>
</p>

<p>
<b>Mapel :</b>
<?php echo htmlspecialchars($data['mata_pelajaran']); ?>
</p>

<p>
<b>Nilai :</b>
<?php echo number_format($data['nilai'],2); ?>
</p>

<p>
<b>Pelanggaran :</b>
<?php echo $data['jumlah_pelanggaran']; ?>
</p>

</div>

<?php
$no=1;

foreach($jawaban as $j):
?>

<div class="card">

<h3>
Soal <?php echo $no++; ?>
</h3>

<p>
<?php echo $j['pertanyaan']; ?>
</p>

<hr>

<p>
<b>Jawaban Siswa :</b>
<?php echo $j['jawaban_dipilih']; ?>
</p>

<p>
<b>Kunci Jawaban :</b>
<?php echo $j['kunci_jawaban']; ?>
</p>

<p>

<b>Status :</b>

<?php
if($j['status_benar']){
?>
<span class="benar">
BENAR
</span>
<?php
}else{
?>
<span class="salah">
SALAH
</span>
<?php
}
?>

</p>

</div>

<?php endforeach; ?>

<div style="text-align:center;margin:30px 0;">

    <a
        href="nilai.php"
        style="
            background:#007bff;
            color:white;
            padding:12px 20px;
            border-radius:5px;
            text-decoration:none;
            font-weight:bold;
        "
    >
        ← Kembali
    </a>

</div>